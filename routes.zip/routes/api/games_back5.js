const express = require("express");
const router = express.Router();
const axios = require('axios');
const cryptoo = require('crypto')
const querystring = require('querystring')
const url = require('url');
const cors = require("cors");
const User = require("../../models/User");
const SloteGames = require("../../models/SlotegratorGames");
const ObjectID = require("mongodb").ObjectID;
const { v4: uuidv4 } = require('uuid');

//index, show
const apiUrl = 'https://staging.slotegrator.network/api/index.php/v1/games';
const merchantId = '1a2fc693659a847a9239746ae3709143';
const merchantKey = '346cfad54cc098d7dde4ea3a7d8178016149e7a9';
const time = Math.floor(Date.now() / 1000).toString();

const nonce = cryptoo
  .createHash('md5')
  .update(cryptoo.randomBytes(16))
  .digest('hex');

const headers = {
  'X-Merchant-Id': merchantId,
  'X-Timestamp': time,
  'X-Nonce': nonce,
};
// X-Sign generate
function calculateXSign(headers, params) {
  const mergedObject = { ...headers, ...params };
  const sortedKeys = Object.keys(mergedObject).sort();
  const sortedObject =
    sortedKeys.reduce((obj, key) => {
      obj[key] = mergedObject[key];
      return obj;
    }, {});
  const queryString = querystring.stringify(sortedObject);
  const hmac = cryptoo.createHmac('sha1', merchantKey);
  hmac.update(queryString);
  const sign = hmac.digest('hex');
  return { sign, queryString };
}

// GET game list
router.get('/gamelist', async (req, res) => {
  const currentPage = req.query.page;
  const time = Math.floor(Date.now() / 1000).toString();
  const headers = {
    'X-Merchant-Id': merchantId,
    'X-Timestamp': time,
    'X-Nonce': nonce,
  };
  const requestParams = {
    page: currentPage,
  };

  const { sign } = calculateXSign(headers, requestParams)
  const requestOptions = {
    headers: {
      'X-Merchant-Id': merchantId,
      'X-Timestamp': time,
      'X-Nonce': nonce,
      'X-Sign': sign,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  };
  try {
    const apiUrlWithQuery = url.format({
      pathname: apiUrl, query: requestParams
    });
    const response = await axios.get(apiUrlWithQuery, requestOptions);
    console.log('data successfully fetched!');
    res.header("Access-Control-Allow-Origin", "*");
    res.json(response.data);
  } catch (error) {
    console.log(error.response.data);
    res.status(500).json({
      error:
        error.message
    });
  }
});


// Init game
router.post('/gameinit', async (req, res) => {
  const { currency, game_uuid, player_id, player_name, session_id } = req.query;
  const time = Math.floor(Date.now() / 1000).toString();
  const headers = {
    'X-Merchant-Id': merchantId,
    'X-Timestamp': time,
    'X-Nonce': nonce,
  };
  const requestParams = {
    currency: currency,
    game_uuid: game_uuid,
    player_id: player_id,
    player_name: player_name,
    language: 'en',
    session_id: session_id,
    return_url: 'https://betbay.io/#/slot-game',
  };

  await SloteGames.collection.insertOne({ amount: 0,currency: currency,game_uuid: game_uuid,player_id: player_id,session_id: session_id,type: 'init',createdAt: new Date(),updatedAt: new Date()});

  const { sign, queryString } = calculateXSign(headers, requestParams)

  const options = {
    method: 'POST',
    headers: {
      'X-Merchant-Id': merchantId,
      'X-Timestamp': time,
      'X-Nonce': nonce,
      'X-Sign': sign,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    data: queryString
  };
  try {

    const apiUrlWithQuery = url.format({ pathname: `${apiUrl}/init` });
    const response = await axios(apiUrlWithQuery, options);

    res.json(response.data);
  } catch (error) {
    res.status(500).json({
      error:
        error.message
    });
  }
});




  // Integrator Endpoint for Game Aggregator communication
  router.post('/callback/datas', async(req, res) => {

    const { action } = req.body; 

    if (action === 'balance') {
        try{
          const { currency, player_id, session_id, action } = req.body; 
        // const userObjectID = new ObjectID(player_id);      
                  
          const user = await User.findById(player_id).select('name email currency');  
          if (!user) {
            return  res.status(200).json({
              error_code: "INTERNAL_ERROR",
              error_description: "This user does not exist in our system.",
            });
          }else{
            if(user.currency > 0){
                const balance_result = {
                  balance: user.currency,
                  currency: "EUR",
                };          
                return   res.status(200).json(balance_result);
            }else{
              return  res.status(200).json({
                error_code: "INSUFFICIENT_FUNDS",
                error_description: "Not enough money to continue playing.",
              });
            }          
          }
        } catch (error) {
          return res.status(200).json({
            error_code: "INTERNAL_ERROR",
            error_description: "This user does not exist in our system.",
          });
        }
    } else if (action === 'win') {
      try {          
        const { amount, currency, game_uuid, player_id, transaction_id, session_id , type, freespin_id, quantity, round_id, finished} = req.body; 
       // const userObjectID = new ObjectID(player_id);
          
          const user = await User.findById(player_id).select('name email currency');  

          if (!user) {
            return   res.status(200).json({
              error_code: "INTERNAL_ERROR",
              error_description: "This user does not exist in our system.",
            });        
          }

          if (amount <= 0) {
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: transaction_id,
            });        
          }

          const checkDuplicate = await SloteGames.find({
            $and: [
              { transaction_id: transaction_id },
              { session_id: session_id }
            ]
          });

          if (checkDuplicate.length === 0) {} else{
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: transaction_id,
            });        
          }        

       
            const currentBalance = user.currency;  
            const updatedBalance = parseFloat(currentBalance) + parseFloat(amount);
            user.currency = updatedBalance.toFixed(2);
           
            await user.save();    
            
            await SloteGames.collection.insertOne({ amount: amount,currency: currency,game_uuid: game_uuid,player_id: player_id,transaction_id: transaction_id,session_id: session_id,type: type,freespin_id: freespin_id,quantity: quantity,round_id: round_id,finished: finished,createdAt: new Date(),updatedAt: new Date()});

            const user_update = await User.findById(player_id).select('name email currency');  
            const response = {
              balance: user_update.currency,
              transaction_id: uuidv4(),
            };
            return    res.status(200).json(response);         
                       
        } catch (error) {
          return   res.status(200).json({
            error_code: "INTERNAL_ERROR",
            error_description: "Something went wrong.",
          });    
        }
    } else if (action === 'bet') {
      try {                          
        const { amount, currency, game_uuid, player_id, transaction_id, session_id , type, freespin_id, quantity, round_id, finished,} = req.body; 
        //  const userObjectID = new ObjectID(player_id);
          
          const user = await User.findById(player_id).select('name email currency');     
  
          if (!user) {
            return   res.status(200).json({
              error_code: "INTERNAL_ERROR",
              error_description: "This user does not exist in our system.",
            });        
          }

          if (amount <= 0) {
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: transaction_id,
            });        
          }

          const checkDuplicate = await SloteGames.find({
            $and: [
              { transaction_id: transaction_id },
              { session_id: session_id }
            ]
          });

          if (checkDuplicate.length === 0) {} else{
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: transaction_id,            
            });        
          }         
        
          const currentBalance = user.currency;          
          const updatedBalance = currentBalance - amount;
          if (updatedBalance > 0) {
              
            user.currency = updatedBalance.toFixed(2);
           
              await user.save();

              await SloteGames.collection.insertOne({ amount: amount,currency: currency,game_uuid: game_uuid,player_id: player_id,transaction_id: transaction_id,session_id: session_id,type: type,freespin_id: freespin_id,quantity: quantity,round_id: round_id,finished: finished,createdAt: new Date(),updatedAt: new Date()});

              const user_update = await User.findById(player_id).select('name email currency');  
              const response = {
                balance: user_update.currency,
                transaction_id: uuidv4(),
              };
              return      res.status(200).json(response);         
           
          } else {
            return     res.status(200).json({
                error_code: "INSUFFICIENT_FUNDS",
                error_description: "Not enough money to continue playing.",
              });
          }
        } catch (error) {
          return  res.status(200).json({
            error_code: "INTERNAL_ERROR",
            error_description: "Something went wrong.",
          });
         
        }
    } else if (action === 'refund') {
       try {   
        const { amount, currency, game_uuid, player_id, bet_transaction_id, session_id , type, freespin_id, quantity, round_id, finished,} = req.body; 

        const user = await User.findById(player_id).select('name email currency');  

          if (!user) {
            return   res.status(200).json({
              error_code: "INTERNAL_ERROR",
              error_description: "This user does not exist in our system.",
            });        
          }
          
          if (amount <= 0) {
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: transaction_id,
            });        
          }

        

         const checkDuplicate = await SloteGames.find({
            $and: [
              { transaction_id: bet_transaction_id },
              { type: type },
              { session_id: session_id }
            ]
          });            
        
          if (checkDuplicate.length === 0) {} else{
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: bet_transaction_id,              
            });        
          }
        
          const currentBalance = user.currency;         
          const updatedBalance = parseFloat(currentBalance) + parseFloat(amount);          
          user.currency = updatedBalance.toFixed(2);             
          await user.save();    
            
          await SloteGames.collection.insertOne({ amount: amount,currency: currency,game_uuid: game_uuid,player_id: player_id,transaction_id: bet_transaction_id,session_id: session_id,type: type,freespin_id: freespin_id,quantity: quantity,round_id: round_id,finished: finished,createdAt: new Date(),updatedAt: new Date()});

          const user_update = await User.findById(player_id).select('name email currency');  
          const response = {
            balance: user_update.currency,
            transaction_id: uuidv4(),
          };
          return   res.status(200).json(response);         
        
          
        } catch (error) {
          return  res.status(200).json({
            error_code: "INTERNAL_ERROR",
            error_description: "Something went wrong.",
          });    
        }    
    } else {
      res.status(200).json({
        error_code: "INTERNAL_ERROR",
        error_description: "Invalid action parameter.",
      });     
    }    

  });


  // Integrator Endpoint for Game Aggregator communication
  router.post('/callback/datas_back', async(req, res) => {

    const { action } = req.body; 

    switch (action) {
      case 'balance':

        try{
              const { currency, player_id, session_id, action } = req.body; 
             // const userObjectID = new ObjectID(player_id);      
                      
              const user = await User.findById(player_id).select('name email currency');  
              if (!user) {
                res.status(200).json({
                  error_code: "INTERNAL_ERROR",
                  error_description: "This user does not exist in our system.",
                });
              }else{
                if(user.currency > 0){
                    const balance_result = {
                      balance: user.currency,
                      currency: "EUR",
                    };          
                    res.status(200).json(balance_result);
                }else{
                  res.status(200).json({
                    error_code: "INSUFFICIENT_FUNDS",
                    error_description: "Not enough money to continue playing.",
                  });
                }
              
              }
        } catch (error) {
          return res.status(200).json({
            error_code: "INTERNAL_ERROR",
            error_description: "This user does not exist in our system.",
          });
        }
        break;
      case 'win':
        try {
          
          const { amount, currency, game_uuid, player_id, transaction_id, session_id , type, freespin_id, quantity, round_id, finished} = req.body; 
         // const userObjectID = new ObjectID(player_id);
            
           const user = await User.findById(player_id).select('name email currency');  
  
           if (!user) {
              return   res.status(200).json({
                error_code: "INTERNAL_ERROR",
                error_description: "This user does not exist in our system.",
              });        
            }

            if (amount <= 0) {
              return  res.status(200).json({
                balance: user.currency,
                transaction_id: transaction_id,
              });        
            }

            const checkDuplicate = await SloteGames.find({
              $and: [
                { transaction_id: transaction_id },
                { session_id: session_id }
              ]
            });

            if (checkDuplicate.length === 0) {} else{
              return  res.status(200).json({
                balance: user.currency,
                transaction_id: transaction_id,
              });        
            }
          

         
            const currentBalance = user.currency;  
          
            const updatedBalance = parseFloat(currentBalance) + parseFloat(amount);
            
              user.currency = updatedBalance.toFixed(2);
             
              await user.save();    
              
              await SloteGames.collection.insertOne({ amount: amount,currency: currency,game_uuid: game_uuid,player_id: player_id,transaction_id: transaction_id,session_id: session_id,type: type,freespin_id: freespin_id,quantity: quantity,round_id: round_id,finished: finished,createdAt: new Date(),updatedAt: new Date()});

              const user_update = await User.findById(player_id).select('name email currency');  
              const response = {
                balance: user_update.currency,
                transaction_id: uuidv4(),
              };
              return    res.status(200).json(response);         
                         
          } catch (error) {
            res.status(200).json({
              error_code: "INTERNAL_ERROR",
              error_description: "Something went wrong.",
            });    
          }
          break;
      case 'bet':
        try {
                          
        const { amount, currency, game_uuid, player_id, transaction_id, session_id , type, freespin_id, quantity, round_id, finished,} = req.body; 
        //  const userObjectID = new ObjectID(player_id);
          
          const user = await User.findById(player_id).select('name email currency');     
  
          if (!user) {
             res.status(200).json({
              error_code: "INTERNAL_ERROR",
              error_description: "This user does not exist in our system.",
            });        
          }

          if (amount <= 0) {
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: transaction_id,
            });        
          }

          const checkDuplicate = await SloteGames.find({
            $and: [
              { transaction_id: transaction_id },
              { session_id: session_id }
            ]
          });

          if (checkDuplicate.length === 0) {} else{
            return  res.status(200).json({
              balance: user.currency,
              transaction_id: transaction_id,            
            });        
          }

         
        
          const currentBalance = user.currency;  
        
          const updatedBalance = currentBalance - amount;
          if (updatedBalance > 0) {
              
            user.currency = updatedBalance.toFixed(2);
           
              await user.save();

              await SloteGames.collection.insertOne({ amount: amount,currency: currency,game_uuid: game_uuid,player_id: player_id,transaction_id: transaction_id,session_id: session_id,type: type,freespin_id: freespin_id,quantity: quantity,round_id: round_id,finished: finished,createdAt: new Date(),updatedAt: new Date()});

              const user_update = await User.findById(player_id).select('name email currency');  
              const response = {
                balance: user_update.currency,
                transaction_id: uuidv4(),
              };
              res.status(200).json(response);         
           
          } else {
              res.status(200).json({
                error_code: "INSUFFICIENT_FUNDS",
                error_description: "Not enough money to continue playing.",
              });
          }
        } catch (error) {
          res.status(200).json({
            error_code: "INTERNAL_ERROR",
            error_description: "Something went wrong.",
          });
         
        }
        break;
      case 'refund':
         try {
    
          
          const { amount, currency, game_uuid, player_id, bet_transaction_id, session_id , type, freespin_id, quantity, round_id, finished,} = req.body; 
        //  const userObjectID = new ObjectID(player_id);
            
           const user = await User.findById(player_id).select('name email currency');  
  
            if (!user) {
               res.status(200).json({
                error_code: "INTERNAL_ERROR",
                error_description: "This user does not exist in our system.",
              });        
            }
            
            if (amount <= 0) {
              return  res.status(200).json({
                balance: user.currency,
                transaction_id: transaction_id,
              });        
            }

            const checkDuplicate = await SloteGames.find({
              $and: [
                { transaction_id: bet_transaction_id },
                { type: type },
                { session_id: session_id }
              ]
            });            
          
            if (checkDuplicate.length === 0) {} else{
              return  res.status(200).json({
                balance: user.currency,
                transaction_id: bet_transaction_id,              
              });        
            }
          
            const currentBalance = user.currency;         
            const updatedBalance = parseFloat(currentBalance) + parseFloat(amount);          
            user.currency = updatedBalance.toFixed(2);             
            await user.save();    
              
            await SloteGames.collection.insertOne({ amount: amount,currency: currency,game_uuid: game_uuid,player_id: player_id,transaction_id: bet_transaction_id,session_id: session_id,type: type,freespin_id: freespin_id,quantity: quantity,round_id: round_id,finished: finished,createdAt: new Date(),updatedAt: new Date()});

            const user_update = await User.findById(player_id).select('name email currency');  
            const response = {
              balance: user_update.currency,
              transaction_id: uuidv4(),
            };
            res.status(200).json(response);         
          
            
          } catch (error) {
            res.status(200).json({
              error_code: "INTERNAL_ERROR",
              error_description: "Something went wrong.",
            });    
          }       
       
        break;
      default:
        res.status(200).json({
          error_code: "INTERNAL_ERROR",
          error_description: "Something went wrong.",
        });
    }

  });



  

  // Init game
  router.post('/self-validate', async (req, res) => {

  //const apiUrl2 = 'https://gis.slotegrator.com/api/index.php/v1/self-validate';

  const time = Math.floor(Date.now() / 1000).toString();
  const headers = {
    'X-Merchant-Id': merchantId,
    'X-Timestamp': time,
    'X-Nonce': nonce,
  };

  const { amount, game_uuid, player_id, round_id, transaction_id, session_id,type,createdAt} = req.query;
  const requestParams  = {
    success: true,
    log: {
      amount: amount,
      currency: "EUR",
      game_uuid: game_uuid,
      player_id: player_id,
      transaction_id: transaction_id,
      session_id: session_id,
      type: type,
      freespin_id: null,
      quantity: null,
      round_id: round_id,
      finished: null,
      createdAt: createdAt,
      updatedAt: createdAt
    }
  };
 
  // log: {
  //   amount: "0",
  //   currency: "EUR",
  //   game_uuid: "af7b23b5087431217f2fdc508d250958898908d2",
  //   player_id: "64aac1ab0f1b810699bf1f64",
  //   transaction_id: "0637dead-8359-465b-a89d-e482c2db961a",
  //   session_id: "79f8c749-64b5-441f-8fd3-baf82c05ce27",
  //   type: "init",
  //   freespin_id: null,
  //   quantity: null,
  //   round_id: null,
  //   finished: null,
  //   createdAt: "2023-07-09T14:22:44.423Z",
  //   updatedAt: "2023-07-09T14:22:44.423Z"
  // }

  const { sign, queryString } = calculateXSign(headers, requestParams)

  const options = {
    method: 'POST',
    headers: {
      'X-Merchant-Id': merchantId,
      'X-Timestamp': time,
      'X-Nonce': nonce,
      'X-Sign': sign,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    data: queryString
  };
  try {
    //const apiUrlWithQuery = url.format({ pathname: `${apiUrl}/self-validate` });
    const apiUrlWithQuery = url.format({ pathname: `https://staging.slotegrator.com/api/index.php/v1/self-validate`});
    const response = await axios(apiUrlWithQuery, options);

    res.json(response.data);
  } catch (error) {
    res.status(500).json({
      error:
        error.message
    });
  }




    // res.status(200).json(response);
    
  });




const isToday = (someDate) => {
  const today = new Date()
  someDate = new Date(someDate)
  return (someDate.getDate() ==
    today.getDate() && someDate.getMonth() == today.getMonth()
    && someDate.getFullYear() == today.getFullYear());
}

module.exports = router;