// import {useEffect, useState} from 'react';
const express = require("express");
const mongoose = require("mongoose");
const router = express.Router();
const bcrypt = require("bcryptjs");
const User = require("../../models/User");
const keys = require("../../config/keys_development");
const validateRegisterInput = require("../../validation/register");
const validateLoginInput = require("../../validation/login");
const validateAgentInput = require("../../validation/agent");
const validateAgentWithdraw = require("../../validation/agentWithdraw");
const quickSort = require("../../util/sort");
const BalanceDeposit = require("../../models/BalanceDeposit");
const AgentBLTR = require("../../models/AgentBLTR");
const UserBLTR = require("../../models/UserBLTR");
// const Agent = require("../../models/Agent");
const AgentWithdraw = require("../../models/AgentWithdraw");

//// ================================ From Admin dashboard =========================== //////

// transfer,update Agent , User table

router.post("/agent_transfer_update", (req, res) => {
  //  let gameId = req.body.gameId

  User.findOne({ user_id: req.body.user_id }, (err, user) => {
    if (err) {
      return res.status(422).json("user not exist!");
    }
    if (!user) {
      return res.status(404).json({ user_id: "This user does not exist" });
    }

    const AgentEmail = req.body.agentEmail;

    User.findOne({ email: req.body.agentEmail }, (err, agent) => {
      const Agentcurrency = Number(agent.currency);
      const transferMoney = Number(req.body.amount);
      console.log("Money: " + Agentcurrency + " Email: " + AgentEmail);

      const checkBalance = Agentcurrency < transferMoney;

      if (checkBalance) {
        return res.status(422).json({ checkBalance: "Not Available Money" });
      } else {
        // T-pin security

        if (!agent) {
          return res.status(404).json({ s_key: "This user does not exist" });
        }

        const tpin = agent.tpin;
        const s_key = req.body.s_key;
        const AgentEmail = req.body.agentEmail;

        // console.log("T-pin: " + tpin + " Agent Email: " + AgentEmail + " S-key " + s_key );

        bcrypt.compare(req.body.s_key, agent.tpin).then((isMatch) => {
          if (!!isMatch) {
            // update User Table  Currency Field
            var date = new Date(Date.now());
            // User.findOne({ email: req.body.email }, (err, user) => {
            const oldCurrncy = Number(user.currency);
            const newCurrency = Number(req.body.amount);
            const currency = oldCurrncy + newCurrency;

            // console.log(
            //   "oldCurrncy: " +
            //     oldCurrncy +
            //     " newCurrency: " +
            //     newCurrency +
            //     " Total currency " +
            //     currency
            // );

            //  });

            User.updateOne(
              { user_id: req.body.user_id },
              { currency: currency }
            )
              .then((user) => res.json(user))
              .catch((err) => console.log(err));

            // Agent user table Balance Minus

            const AgentCurrencyHas = Number(agent.currency);
            const NewTransferMoney = Number(req.body.amount);
            const AgentNewAmount = AgentCurrencyHas - NewTransferMoney;

            User.updateOne(
              { email: req.body.agentEmail },
              { currency: AgentNewAmount }
            )
              .then((user) => res.json(user))
              .catch((err) => console.log(err));

            //  UserBLTR Table Insert

            const AgentBLTRData = new AgentBLTR({
              user_id: req.body.user_id,
              status_type: 1,
              amount: req.body.amount,
              s_key: req.body.s_key,
              history: [{ x: date }],
            });

            AgentBLTRData.save()
              .then((agent) => res.json(agent))
              .catch((err) => console.log(err));
          } else {
            return res.status(400).json({ TPIN: "Incorrect T-PIN" });
          }
        });
      }
    });
  });
});

// Show all User

router.get("/getdataAllUser", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  User.find().then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

//  User index read role_as: 3
router.get("/getdataUser", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  User.find({ role_as: 3 }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

// paginate user

router.get("/paginatedgetdataUser", async (req, res) => {
  const allUser = await User.find({ role_as: 3, sender_id : req.query.user_id });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

// get agent index read
router.get("/getdataAgent", (req, res) => {

  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  User.find({ role_as: 2 }).then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
  
});

// ##### Paginate ##### // get agent paginatedUsers
router.get("/paginatedAgent", async (req, res) => {

  const allUser = await User.find({ role_as: 2 });
  const page = parseInt(req.query.page)
  const limit = parseInt(req.query.limit)

  const startIndex = (page - 1) * limit
  const lastIndex = (page) * limit

  const results = {}
  results.totalUser=allUser.length;
  results.pageCount=Math.ceil(allUser.length/limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    }
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    }
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results)
  
});

// paginate user jwt data
// router.post("/userData", async (req, res) => {
//   const { token } = req.body;
//   try {
//     const user = jwt.verify(token, JWT_SECRET, (err, res) => {
//       if (err) {
//         return "token expired";
//       }
//       return res;
//     });
//     console.log(user);
//     if (user == "token expired") {
//       return res.send({ status: "error", data: "token expired" });
//     }

//     const useremail = user.email;
//     User.findOne({ email: useremail })
//       .then((data) => {
//         res.send({ status: "ok", data: data });
//       })
//       .catch((error) => {
//         res.send({ status: "error", data: error });
//       });
//   } catch (error) { }
// });

// agent create

router.post("/agent_create", (req, res) => {
  const { errors, isValid } = validateAgentInput(req.body);

  if (!isValid) {
    return res.status(401).json(errors);
  }

  // Check to make sure nobody has already registered with a duplicate email

  User.findOne({ email: req.body.email }).then((user) => {
    if (user) {
      // Throw a 400 error if the email address already exists
      return res
        .status(400)
        .json({ email: "Already registered with this address" });
    } else {
      // or latest query

      async function getAgent() {
        try {
          // Otherwise create a new user

          const agentID = User.find({ role_as: "2" }).then((user) => {
            // console.log("Agent: " + user);
          });
          // if (agentID) {
          var date = new Date(Date.now());
          const newRandomNumber = () => {
            const min = 100; // Minimum 3-digit number
            const max = 999; // Maximum 3-digit number
            const randomNumber = Math.floor(
              Math.random() * (max - min + 1) + min
            );
            return randomNumber;
          };
          // const randomNumber = newRandomNumber();

          const Agents = await User.find({ role_as: "2" })
            .sort({ _id: -1 })
            .limit(1);

          const lastId = Agents[0].user_id;
          let str = lastId;
          let newStr = str.replace(/^./, "");

          const latestId = Number(newStr);
          const Randomuser_id = Number(newRandomNumber());
          const IdAdd = latestId + Randomuser_id;
          const New_user_id = "R" + IdAdd;

          // }

          const newAgent = new User({
            user_id: New_user_id,
            handle: req.body.handle,
            email: req.body.email,
            password: req.body.password,
            tpin: req.body.password,
            mobile: req.body.mobile,
            ref_percentage: req.body.ref_percentage,
            deposit_percentage: req.body.deposit_percentage,
            status: "MainReseller",
            role_as: 2,
            // currency: 0,
            history: [{ x: date, y: 1000 }],
          });

          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newAgent.password, salt, (err, hash) => {
              if (err) throw err;
              newAgent.password = hash;

              bcrypt.hash(newAgent.tpin, salt, (err, hash) => {
                if (err) throw err;
                newAgent.tpin = hash;
                newAgent
                  .save()
                  .then((user) => res.json(user))
                  .catch((err) => console.log(err));
              });
            });
          });
        } catch (error) {
          console.log(error.message);
        }
      }

      getAgent();
    }
  });
});

//  edit agent
router.get("/editagent/:_id").get(function (req, res) {
  const rowId = req.params._id;
  User.findOne({ _id: rowId }).then((user) => res.json(user));
});

// update  agent
router.post("/updateAgent/:_id", (req, res) => {
  const { errors, isValid } = validateAgentInput(req.body);
  if (!isValid) {
    return res.status(401).json(errors);
  }
  const rowId = req.params._id;
  // console.log("Id: " + rowId);
  // handle, email, password, mobile,  ref_percentage, deposit_percentage
  const handle = req.body.handle;
  const email = req.body.email;
  const password = req.body.password;
  const mobile = req.body.mobile;
  const ref_percentage = req.body.ref_percentage;
  const deposit_percentage = req.body.deposit_percentage;

  bcrypt.genSalt(10, (err, salt) => {
    bcrypt.hash(password, salt, (err, hash) => {
      if (err) throw err;
      const password = hash;

      User.updateOne(
        { _id: rowId },
        {
          handle: handle,
          email: email,
          password: password,
          mobile: mobile,
          ref_percentage: ref_percentage,
          deposit_percentage: deposit_percentage,
        }
      )
        .then((user) => res.json(user))
        .catch((err) => console.log(err));
    });
  });
});

// Delete agent
router.delete("/deleteAgent/:id", async (req, res) => {
  try {
    const rowId = req.params.id;

    // Delete the row with the specified ID
    const deletedRow = await User.findByIdAndDelete(rowId);

    if (deletedRow) {
      res.status(200).json({ message: "Row deleted successfully" });
    } else {
      res.status(404).json({ message: "Row not found" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// ### SubReseller create

router.post("/SubResellerCreate", (req, res) => {
  const { errors, isValid } = validateAgentInput(req.body);

  if (!isValid) {
    return res.status(401).json(errors);
  }

  // Check to make sure nobody has already registered with a duplicate email

  User.findOne({ email: req.body.email }).then((user) => {
    if (user) {
      // Throw a 400 error if the email address already exists
      return res
        .status(400)
        .json({ email: "Already registered with this address" });
    } else {
      // or latest query

      async function getAgent() {
        try {
          // Otherwise create a new user

          const agentID = User.find({ role_as: "2" }).then((user) => {
            // console.log("Agent: " + user);
          });
          // if (agentID) {
          var date = new Date(Date.now());
          const newRandomNumber = () => {
            const min = 100; // Minimum 3-digit number
            const max = 999; // Maximum 3-digit number
            const randomNumber = Math.floor(
              Math.random() * (max - min + 1) + min
            );
            return randomNumber;
          };
          // const randomNumber = newRandomNumber();

          const Agents = await User.find({ role_as: "2" })
            .sort({ _id: -1 })
            .limit(1);

          const lastId = Agents[0].user_id;
          let str = lastId;
          let newStr = str.replace(/^./, "");

          const latestId = Number(newStr);
          const Randomuser_id = Number(newRandomNumber());
          const IdAdd = latestId + Randomuser_id;
          const New_user_id = "R" + IdAdd;

          // }

          const newAgent = new User({
            user_id: New_user_id,
            handle: req.body.handle,
            email: req.body.email,
            password: req.body.password,
            tpin: req.body.password,
            mobile: req.body.mobile,
            ref_percentage: req.body.ref_percentage,
            deposit_percentage: req.body.deposit_percentage,
            status: "SubReseller",
            role_as: 2,
            // currency: 0,
            history: [{ x: date, y: 1000 }],
          });

          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newAgent.password, salt, (err, hash) => {
              if (err) throw err;
              newAgent.password = hash;

              bcrypt.hash(newAgent.tpin, salt, (err, hash) => {
                if (err) throw err;
                newAgent.tpin = hash;
                newAgent
                  .save()
                  .then((user) => res.json(user))
                  .catch((err) => console.log(err));
              });
            });
          });
        } catch (error) {
          console.log(error.message);
        }
      }

      getAgent();
    }
  });
});

//  edit SubReseller

router.get("/editsubreseller/:usAutoId").get(function (req, res) {
  const rowId = req.params.id;
  User.findOne({ usAutoId: rowId }).then((user) => res.json(user));
});

// Update SubReseller
// ...

// getdataSubReseller
router.get("/getdataSubReseller", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  User.find({ role_as: 2, status: "SubReseller" }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

// sub reseller paginate

// get agent index read
router.get("/getSubReseller", (req, res) => {

  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  User.find({ role_as: 2, status: "SubReseller" }).then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
  
});

// ##### Paginate ##### // get agent paginatedUsers
router.get("/paginatedSubReseller", async (req, res) => {

  const allUser = await User.find({  role_as: 2, status: "SubReseller" });
  const page = parseInt(req.query.page)
  const limit = parseInt(req.query.limit)

  const startIndex = (page - 1) * limit
  const lastIndex = (page) * limit

  const results = {}
  results.totalUser=allUser.length;
  results.pageCount=Math.ceil(allUser.length/limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    }
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    }
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results)
  
});

// Agent Balance Report
router.get("/AgentBalanceReport", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }
  var mysort = { name: -1 };
  AgentBLTR.find()
    .sort(mysort)
    .then((user) => {
      // UserBLTR.find().then((user) => {
      if (!!user) {
        return res.json(user);
      } else {
        return res.status(404).json({ msg: "User not found" });
      }
    });
});

//  paginatedAgentBalReport
router.get("/paginatedAgentBalReport", async (req, res) => {
  const allUser = await AgentBLTR.find();
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

// withdraw index list ref: "0= Pending, 1= Paid, 2= Rejected,  3 = Block",

// 0= Pending
router.get("/withdrawPending", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  AgentWithdraw.find({ status_type: 0 }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

// paginate withdrawPending
router.get("/paginatedwithdrawPending", async (req, res) => {
  const allUser = await AgentWithdraw.find({ status_type: 0 });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

// 1= Paid
router.get("/withdrawPaid", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  AgentWithdraw.find({ status_type: 1 }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

// paginate  withdrawPaid
router.get("/paginatedwithdrawPaid", async (req, res) => {
  const allUser = await AgentWithdraw.find({ status_type: 1 });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);
  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

// 2= Rejected

router.get("/withdrawRejected", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  AgentWithdraw.find({ status_type: 2 }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

// paginate withdrawRejected

router.get("/paginatedwithdrawRejected", async (req, res) => {
  const allUser = await AgentWithdraw.find({ status_type: 2 });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

// 3 = Block

router.get("/withdrawBlock", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  AgentWithdraw.find({ status_type: 3 }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

// paginate withdrawBlock
router.get("/paginatedwithdrawBlock", async (req, res) => {
  const allUser = await AgentWithdraw.find({ status_type: 3 });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

//Action approve withdraw  Pending  paid

router.delete("/withdrawPaid/:id", async (req, res) => {
  try {
    const rowId = req.params.id;

    AgentWithdraw.findByIdAndUpdate(
      rowId,
      { status_type: 1 },
      function (err, docs) {
        if (err) {
          console.log(err);
        } else {
          // console.log("Updated User : ", docs);
          res.status(200).json({ message: "paid successfully" });
        }
      }
    );
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// withdraw  Pending Rejected

router.delete("/withdrawRejected/:id", async (req, res) => {
  try {
    const rowId = req.params.id;

    AgentWithdraw.findByIdAndUpdate(
      rowId,
      { status_type: 2 },
      function (err, docs) {
        if (err) {
          console.log(err);
        } else {
          // console.log("Updated User : ", docs);
          res.status(201).json({ message: "Rejected successfully" });
        }
      }
    );
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// withdraw  Pending Block

router.delete("/withdrawBlock/:id", async (req, res) => {
  try {
    const rowId = req.params.id;

    AgentWithdraw.findByIdAndUpdate(
      rowId,
      { status_type: 3 },
      function (err, docs) {
        if (err) {
          console.log(err);
        } else {
          // console.log("Updated User : ", docs);
          res.status(202).json({ message: "Updated successfully" });
        }
      }
    );
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// withdraw  Pending Pending

router.delete("/withdrawPending/:id", async (req, res) => {
  try {
    const rowId = req.params.id;

    AgentWithdraw.findByIdAndUpdate(
      rowId,
      { status_type: 0 },
      function (err, docs) {
        if (err) {
          console.log(err);
        } else {
          // console.log("Updated User : ", docs);
          res.status(203).json({ message: "Updated successfully" });
        }
      }
    );
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Affiliate create
router.post("/affiliate_create", (req, res) => {
  const { errors, isValid } = validateAgentInput(req.body);

  if (!isValid) {
    return res.status(401).json(errors);
  }

  // Check to make sure nobody has already registered with a duplicate email

  User.findOne({ email: req.body.email }).then((user) => {
    if (user) {
      // Throw a 400 error if the email address already exists
      return res
        .status(400)
        .json({ email: "Already registered with this address" });
    } else {
      // or latest query

      async function getAgent() {
        try {
          // Otherwise create a new user

          // show agent user  role_as: "2"
          const agentID = User.find({ role_as: "4" }).then((user) => {
            // console.log("Agent: " + user);
          });

          // if (agentID) {

          var date = new Date(Date.now());

          const newRandomNumber = () => {
            const min = 100; // Minimum 3-digit number
            const max = 999; // Maximum 3-digit number
            const randomNumber = Math.floor(
              Math.random() * (max - min + 1) + min
            );
            return randomNumber;
          };

          // const randomNumber = newRandomNumber();

          const Agents = await User.find({ role_as: "4" })
            .sort({ _id: -1 })
            .limit(1);
          const lastId = Agents[0].user_id;

          let str = lastId;
          let newStr = str.replace(/^./, "");

          const latestId = Number(newStr);
          const Randomuser_id = Number(newRandomNumber());
          const IdAdd = latestId + Randomuser_id;
          const New_user_id = "A" + IdAdd;

          // console.log(
          //   " Old: " +
          //     str +
          //     " Last Num: " +
          //     latestId +
          //     " Random: " +
          //     Randomuser_id +
          //     " Total: " +
          //     IdAdd +
          //     " Fresh: " +
          //     New_user_id
          // );

          // }

          const newAgent = new User({
            user_id: New_user_id,
            handle: req.body.handle,
            email: req.body.email,
            password: req.body.password,
            tpin: req.body.password,
            mobile: req.body.mobile,
            ref_percentage: req.body.ref_percentage,
            deposit_percentage: req.body.deposit_percentage,
            status: "MainAffiliate",
            role_as: 4,
            // currency: 0,
            history: [{ x: date, y: 1000 }],
          });

          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newAgent.password, salt, (err, hash) => {
              if (err) throw err;
              newAgent.password = hash;

              bcrypt.hash(newAgent.tpin, salt, (err, hash) => {
                if (err) throw err;
                newAgent.tpin = hash;
                newAgent
                  .save()
                  .then((user) => res.json(user))
                  .catch((err) => console.log(err));
              });
            });
          });
        } catch (error) {
          console.log(error.message);
        }
      }

      getAgent();
    }
  });
});

// edit affiliate
router.get("/editAffiliate/:_id").get(function (req, res) {
  const rowId = req.params._id;
  User.findOne({ _id: rowId }).then((user) => res.json(user));
});

// update affiliate
router.post("/updateaffiliate/:_id", (req, res) => {
  const { errors, isValid } = validateAgentInput(req.body);
  if (!isValid) {
    return res.status(401).json(errors);
  }
  const rowId = req.params._id;
  // console.log("Id: " + rowId);
  // handle, email, password, mobile,  ref_percentage, deposit_percentage
  const handle = req.body.handle;
  const email = req.body.email;
  const password = req.body.password;
  const mobile = req.body.mobile;
  const ref_percentage = req.body.ref_percentage;
  const deposit_percentage = req.body.deposit_percentage;

  bcrypt.genSalt(10, (err, salt) => {
    bcrypt.hash(password, salt, (err, hash) => {
      if (err) throw err;
      const password = hash;

      User.updateOne(
        { _id: rowId },
        {
          handle: handle,
          email: email,
          password: password,
          mobile: mobile,
          ref_percentage: ref_percentage,
          deposit_percentage: deposit_percentage,
        }
      )
        .then((user) => res.json(user))
        .catch((err) => console.log(err));
    });
  });
});

// Delete affiliate
router.delete("/deleteAffiliate/:id", async (req, res) => {
  try {
    const rowId = req.params.id;

    // Delete the row with the specified ID
    const deletedRow = await User.findByIdAndDelete(rowId);

    if (deletedRow) {
      res.status(200).json({ message: "Row deleted successfully" });
    } else {
      res.status(404).json({ message: "Row not found" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Affiliate old  data show edit
router.get("/oldDataAffiliate/:_id", (req, res) => {

  if (req.params._id === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }
    User.find({ _id: req.params._id }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });

});

// getdataAffiliate
router.get("/getdataAffiliate", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  User.find({ role_as: 4 }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

//  paginatedAffiliate
router.get("/paginatedAffiliate", async (req, res) => {

  const allUser = await User.find({ role_as: 4 });
  const page = parseInt(req.query.page)
  const limit = parseInt(req.query.limit)

  const startIndex = (page - 1) * limit
  const lastIndex = (page) * limit

  const results = {}
  results.totalUser=allUser.length;
  results.pageCount=Math.ceil(allUser.length/limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    }
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    }
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results)
  
});

//   ###  SubAffiliate ###

//  SubAffiliate create

router.post("/SubAffiliateCreate", (req, res) => {
  const { errors, isValid } = validateAgentInput(req.body);
  if (!isValid) {
    return res.status(401).json(errors);
  }
  // Check to make sure nobody has already registered with a duplicate email

  User.findOne({ email: req.body.email }).then((user) => {
    if (user) {
      // Throw a 400 error if the email address already exists
      return res
        .status(400)
        .json({ email: "Already registered with this address" });
    } else {
      // or latest query

      async function getAgent() {
        try {
          // Otherwise create a new user

          const agentID = User.find({ role_as: "4" }).then((user) => {
            // console.log("Agent: " + user);
          });
          // if (agentID) {
          var date = new Date(Date.now());
          const newRandomNumber = () => {
            const min = 100; // Minimum 3-digit number
            const max = 999; // Maximum 3-digit number
            const randomNumber = Math.floor(
              Math.random() * (max - min + 1) + min
            );
            return randomNumber;
          };
          // const randomNumber = newRandomNumber();

          const Agents = await User.find({ role_as: "4" })
            .sort({ _id: -1 })
            .limit(1);

          const lastId = Agents[0].user_id;
          let str = lastId;
          let newStr = str.replace(/^./, "");

          const latestId = Number(newStr);
          const Randomuser_id = Number(newRandomNumber());
          const IdAdd = latestId + Randomuser_id;
          const New_user_id = "A" + IdAdd;

          // }

          const newAgent = new User({
            user_id: New_user_id,
            handle: req.body.handle,
            email: req.body.email,
            password: req.body.password,
            tpin: req.body.password,
            mobile: req.body.mobile,
            ref_percentage: req.body.ref_percentage,
            deposit_percentage: req.body.deposit_percentage,
            status: "SubAffiliate",
            role_as: 4,
            // currency: 0,
            history: [{ x: date, y: 1000 }],
          });

          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newAgent.password, salt, (err, hash) => {
              if (err) throw err;
              newAgent.password = hash;

              bcrypt.hash(newAgent.tpin, salt, (err, hash) => {
                if (err) throw err;
                newAgent.tpin = hash;
                newAgent
                  .save()
                  .then((user) => res.json(user))
                  .catch((err) => console.log(err));
              });
            });
          });
        } catch (error) {
          console.log(error.message);
        }
      }

      getAgent();
    }
  });
});

//  edit SubAffiliate

router.get("/editsubreseller/:usAutoId").get(function (req, res) {
  const rowId = req.params.id;
  User.findOne({ usAutoId: rowId }).then((user) => res.json(user));
});

// Update SubAffiliate

// getdataSubAffiliate

router.get("/getdataSubAffiliate", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  User.find({ role_as: 4, status: "SubAffiliate" }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });
});

router.get("/paginatedSubAffiliate", async (req, res) => {
  const allUser = await User.find({role_as: 4, status: "SubAffiliate"});
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

////// ========================== From Agent dashboard ===================== /////////////


router.post("/balance_deposit", async (req, res) => {
  try {
    const newBalanceDeposit = new BalanceDeposit({
      user_id: req.body.user_id,
      amount: req.body.amount,
      deposit_type: 1, //"1= reseller", // You may want to clarify this format
      transaction_id: req.body.transaction_id,
      status_type: 0, //"0 = pending , 1= Paid",
      payment_type: req.body.payment_type //"1= Paid",
    });

    // Save the new BalanceDeposit instance to the database
    const savedBalanceDeposit = await newBalanceDeposit.save();

    return res.status(200).json({ message: 'Successfully created a new deposit.', data: savedBalanceDeposit });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: error.message });
  }
});


//  paginatedUserBalanceReport
router.get("/deposited_report", async (req, res) => {

  const allUser = await BalanceDeposit.find({ deposit_type: 1, user_id : req.query.user_id });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});



router.post("/user_transfer_update", (req, res) => {
  //  let gameId = req.body.gameId

  User.findOne({ user_id: req.body.user_id }, (err, user) => {
    if (err) {
      return res.status(422).json("user not exist!");
    }
    if (!user) {
      return res.status(404).json({ email: "This user does not exist" });
    }

    const AgentEmail = req.body.agentEmail;

    User.findOne({ email: req.body.agentEmail }, (err, agent) => {
      const Agentcurrency = Number(agent.currency);
      const transferMoney = Number(req.body.amount);
      // console.log("Money: " + Agentcurrency + " Email: " + AgentEmail);

      const checkBalance = Agentcurrency < transferMoney;

      if (checkBalance) {
        return res.status(422).json({ checkBalance: "Not Available Money" });
      } else {
        // T-pin security

        if (!agent) {
          return res.status(404).json({ s_key: "This user does not exist" });
        }

        const tpin = agent.tpin;
        const s_key = req.body.s_key;
        const AgentEmail = req.body.agentEmail;

        // console.log("T-pin: " + tpin + " Agent Email: " + AgentEmail + " S-key " + s_key );

        bcrypt.compare(req.body.s_key, agent.tpin).then((isMatch) => {
          if (!!isMatch) {
            // update User Table  Currency Field

            var date = new Date(Date.now());

            const oldCurrncy = Number(user.currency);
            const newCurrency = Number(req.body.amount);

            const currency = newCurrency + oldCurrncy;

            // console.log(
            //   "oldCurrncy: " +
            //     oldCurrncy +
            //     " newCurrency: " +
            //     newCurrency +
            //     " Total currency " +
            //     currency
            // );

            // console.log(currency);

            User.updateOne(
              { user_id: req.body.user_id },
              { currency: currency }
            )
              .then((user) => res.json(user))
              .catch((err) => console.log(err));

            // Agent user table Balance Minus

            const AgentCurrencyHas = Number(agent.currency);
            const NewTransferMoney = Number(req.body.amount);
            const AgentNewAmount = AgentCurrencyHas - NewTransferMoney;

            User.updateOne(
              { email: req.body.agentEmail },
              { currency: AgentNewAmount }
            )
              .then((user) => res.json(user))
              .catch((err) => console.log(err));

            //  UserBLTR Table Insert

            const userBLTRData = new UserBLTR({
              user_id: req.body.user_id,
              status_type: 1,
              amount: req.body.amount,
              s_key: req.body.s_key,
              history: [{ x: date }],
            });

            userBLTRData
              .save()
              .then((agent) => res.json(agent))
              .catch((err) => console.log(err));
          } else {
            return res.status(400).json({ TPIN: "Incorrect T-PIN" });
          }
        });
      }
    });
  });
});

// Agent Balance Report

router.get("/UserBalanceReport", (req, res) => {
  if (req.params.userId === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }
  var mysort = { name: -1 };
  UserBLTR.find()
    .sort(mysort)
    .then((user) => {
      if (!!user) {
        return res.json(user);
      } else {
        return res.status(404).json({ msg: "User not found" });
      }
    });
});

//  paginatedUserBalanceReport
router.get("/paginatedUserBalanceReport", async (req, res) => {
  const allUser = await UserBLTR.find({ role_as: 3, user_id : req.user_id });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});


// AgentWithdraw

router.post("/withdraw", (req, res) => {
  const { errors, isValid } = validateAgentWithdraw(req.body);

  if (!isValid) {
    return res.status(401).json(errors);
  }

  User.findOne({ user_id: req.body.receiver_user_id }, (err, user) => {
    if (err) {
      return res.status(422).json("user not exist!");
    }
    if (!user) {
      return res.status(404).json({ email: "This user does not exist" });
    }

    const AgentEmail = req.body.agentEmail;

    User.findOne({ email: req.body.agentEmail }, (err, agent) => {
      const Agentcurrency = Number(agent.currency);
      const transferMoney = Number(req.body.amount);
      console.log("Money: " + Agentcurrency + " Email: " + AgentEmail);

      const checkBalance = Agentcurrency < transferMoney;

      if (checkBalance) {
        return res.status(422).json({ checkBalance: "Not Available Money" });
      } else {
        // T-pin security

        const tpin = agent.tpin;
        const s_key = req.body.s_key;
        const AgentEmail = req.body.agentEmail;

        // console.log("T-pin: " + tpin + " Agent Email: " + AgentEmail + " S-key " + s_key );

        bcrypt.compare(req.body.s_key, agent.tpin).then((isMatch) => {
          if (!!isMatch) {
            // update Adminuser Table  Currency Field Add

            var date = new Date(Date.now());

            const oldCurrncy = Number(user.currency);
            const newCurrency = Number(req.body.amount);

            const currency = newCurrency + oldCurrncy;

            // console.log(
            //   "oldCurrncy: " +
            //     oldCurrncy +
            //     " newCurrency: " +
            //     newCurrency +
            //     " Total currency " +
            //     currency
            // );

            // console.log(currency);

            User.updateOne(
              { user_id: req.body.receiver_user_id },
              { currency: currency }
            )
              .then((user) => res.json(user))
              .catch((err) => console.log(err));

            // Agent user table Balance Minus

            const AgentCurrencyHas = Number(agent.currency);
            const NewTransferMoney = Number(req.body.amount);
            const AgentNewAmount = AgentCurrencyHas - NewTransferMoney;

            // console.log(
            //   "Money has: " +
            //     AgentCurrencyHas +
            //     " AgentNewAmount: " +
            //     AgentNewAmount
            // );

            User.updateOne(
              { email: req.body.agentEmail },
              { currency: AgentNewAmount }
            )
              .then((user) => res.json(user))
              .catch((err) => console.log(err));

            //  UserBLTR Table Insert

            const agentWithdraw = new AgentWithdraw({
              receiver_user_id: req.body.receiver_user_id,
              user_id: req.body.user_id,
              agentEmail: req.body.agentEmail,
              amount: req.body.amount,
              payment: req.body.payment,
              acc_number: req.body.acc_number,
              status_type: 0,
              s_key: req.body.s_key,
              history: [{ x: date }],
            });

            agentWithdraw
              .save()
              .then((agent) => res.json(agent))
              .catch((err) => console.log(err));
          } else {
            return res.status(400).json({ TPIN: "Incorrect T-PIN" });
          }
        });
      }
    });
  });
});

// from admin Balance Received

router.get("/BlFromAdmin/:user_id", (req, res) => {

  if (req.params.user_id === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  // AgentBLTR.find({ user_id:  req.body.user_id }).then((user) => {
  AgentBLTR.find({ user_id: req.params.user_id }).then((user) => {
    // UserBLTR.find().then((user) => {
    if (!!user) {
      return res.json(user);
    } else {
      return res.status(404).json({ msg: "User not found" });
    }
  });

});

// paginate 

router.get("/paginatedBlFromAdmin/:user_id", async (req, res) => {

  if (req.params.user_id === "undefined") {
    return res.status(422).json({ msg: "userId is undefined" });
  }

  const allUser = await AgentBLTR.find({ user_id: req.params.user_id });
  const page = parseInt(req.query.page);
  const limit = parseInt(req.query.limit);

  const startIndex = (page - 1) * limit;
  const lastIndex = page * limit;

  const results = {};
  results.totalUser = allUser.length;
  results.pageCount = Math.ceil(allUser.length / limit);

  if (lastIndex < allUser.length) {
    results.next = {
      page: page + 1,
    };
  }
  if (startIndex > 0) {
    results.prev = {
      page: page - 1,
    };
  }
  results.result = allUser.slice(startIndex, lastIndex);
  res.json(results);
});

// User jsonWebToken Info
// router.get("/user_jwtinfo", (req, res) => {
//   const AgentEmail = req.body.agentEmail;

//   User.findOne({ email: req.body.agentEmail }, (err, user) => {
//     const Agentcurrency = Number(user.currency);
//     console.log(Agentcurrency);
//   });
// });

module.exports = router;
