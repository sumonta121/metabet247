const express = require("express");
const router = express.Router();
const axios = require('axios');
const cryptoo = require('crypto')
const querystring = require('querystring')
const url = require('url');
const cors = require("cors");
const User = require("../../models/User");
const SlotGames = require("../../models/SlotegratorGames");
const ObjectID = require("mongodb").ObjectID;
//index, show

router.use(cors({
  origin: ["https://xyz-frontend.onrender.com", "https://betbay.io", "http://localhost:3000" ]
}));
const apiUrl = 'https://staging.slotegrator.network/api/index.php/v1/games';
const merchantId = '1a2fc693659a847a9239746ae3709143';
const merchantKey = '346cfad54cc098d7dde4ea3a7d8178016149e7a9';
const time = Math.floor(Date.now() / 1000).toString();

const nonce = cryptoo
  .createHash('md5')
  .update(cryptoo.randomBytes(16))
  .digest('hex');

const headers = {
  'X-Merchant-Id': merchantId,
  'X-Timestamp': time,
  'X-Nonce': nonce,
};
// X-Sign generate
function calculateXSign(headers, params) {
  const mergedObject = { ...headers, ...params };
  const sortedKeys = Object.keys(mergedObject).sort();
  const sortedObject =
    sortedKeys.reduce((obj, key) => {
      obj[key] = mergedObject[key];
      return obj;
    }, {});
  const queryString = querystring.stringify(sortedObject);
  const hmac = cryptoo.createHmac('sha1', merchantKey);
  hmac.update(queryString);
  const sign = hmac.digest('hex');
  return { sign, queryString };
}

// GET game list
router.get('/gamelist'
  , async (req, res) => {

    const requestParams = {
      page: 1,
    };
    const mergedObject = { ...headers, ...requestParams };
    const sortedKeys = Object.keys(mergedObject).sort();
    const sortedObject =
      sortedKeys.reduce((obj, key) => {
        obj[key] = mergedObject[key];
        return obj;
      }, {});
    const queryString = querystring.stringify(sortedObject);
    const hmac = cryptoo.createHmac('sha1', merchantKey);
    hmac.update(queryString);
    const xSign = hmac.digest('hex');
    const requestOptions = {
      headers: {
        'X-Merchant-Id': merchantId,
        'X-Timestamp': time,
        'X-Nonce': nonce,
        'X-Sign': xSign,
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    };
    try {
      const apiUrlWithQuery = url.format({
        pathname: apiUrl, query: requestParams
      });
      const response = await axios.get(apiUrlWithQuery, requestOptions);
      console.log('sign:', xSign)
      console.log(response);
      res.json(response.data);
    } catch (error) {
      console.log(error);
      res.status(500).json({
        error:
          error.message
      });
    }
  });


// Init game
router.post('/gameinit', async (req, res) => {
  const { currency, game_uuid, player_id, player_name, session_id } = req.query;

  const requestParams = {
    currency: currency,
    game_uuid: game_uuid,
    player_id: player_id,
    player_name: player_name,
    language: 'en',
    session_id: session_id,
    return_url: 'https://betbay.io/game/callback/datas/',
  };

  const { sign, queryString } = calculateXSign(headers, requestParams)

  const options = {
    method: 'POST',
    headers: {
      'X-Merchant-Id': merchantId,
      'X-Timestamp': time,
      'X-Nonce': nonce,
      'X-Sign': sign,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    data: queryString
  };
  try {

    const apiUrlWithQuery = url.format({ pathname: `${apiUrl}/init` });
    const response = await axios(apiUrlWithQuery, options);

    res.json(response.data);
  } catch (error) {
    res.status(500).json({
      error:
        error.message
    });
  }
});


// router.post("/callback/datas", (req, res) => {
//   const { currency, player_id, session_id, action } = req.body;
//   res.json(player_id);
//   const balance = {
//     balance: 1000,
//     currency: "EUR",
//   };
//   res.json(balance);
// });


  // Integrator Endpoint for Game Aggregator communication
  router.post('/callback/datas', async(req, res) => {

    const { currency, player_id, session_id, action } = req.body; 
    const userObjectID = new ObjectID(player_id);
   
    // Process the Game Aggregator's calls based on the action parameter
    switch (action) {
      case 'balance':
        // Handle Balance request
        try {
          const user = await User.findById(userObjectID).select('name email currency');  
          if (user) {     
            const balance = {
              balance: user.currency,
              currency: "EUR",
            };
            res.status(200).json(balance);
          } else {
            res.status(404).json({ error: 'User not found' });
          }
        } catch (error) {
          res.status(500).json({ error: 'internel error' });
        }

       // const balanceResponse = handleBalanceRequest(player_id, currency, session_id);
     
        break;
      case 'win':
        // Handle Win notification
        handleWinNotification(player_id, amount);
        res.sendStatus(200);
        break;
      case 'bet':
        // Handle Bet notification
        // handleBetNotification(player_id, amount);
        res.sendStatus(200);
        break;
      case 'refund':
        // Handle Refund request
        handleRefundRequest(player_id, amount);
        res.sendStatus(200);
        break;
      default:
        res.status(400).send('Bad Request');
    }

  });


  // Handler functions for different actions
  function handleBalanceRequest(playerId, currency, sessionId) {
    // Implement your logic to handle the Balance request
    // Example:
    const balance = getPlayerBalance(playerId, currency, sessionId); // Replace this with your logic to retrieve the player's balance
    return {
      balance: balance
    };
  }

  function handleWinNotification(playerId, amount) {
    // Implement your logic to handle the Win notification
    // Example:
    updatePlayerBalance(playerId, amount); // Replace this with your logic to update the player's balance
  }

  function handleBetNotification(playerId, amount) {
    // Implement your logic to handle the Bet notification
    // Example:
    updatePlayerBalance(playerId, -amount); // Replace this with your logic to update the player's balance
  }

  function handleRefundRequest(playerId, amount) {
    // Implement your logic to handle the Refund request
    // Example:
    updatePlayerBalance(playerId, amount); // Replace this with your logic to update the player's balance
  }


    // Helper functions for handling player balance
  function getPlayerBalance(playerId, currency, sessionId) {
    // Implement your logic to retrieve the player's balance
    // Example:      
   
     // Replace this with your logic to fetch the player's balance from the database or any other source

  }

  function updatePlayerBalance(playerId, amount) {
    // Implement your logic to update the player's balance
    // Example:
    // Update the player's balance in the database or any other source based on the provided amount
  }




const isToday = (someDate) => {
  const today = new Date()
  someDate = new Date(someDate)
  return (someDate.getDate() ==
    today.getDate() && someDate.getMonth() == today.getMonth()
    && someDate.getFullYear() == today.getFullYear());
}
router.get('/index', (req, res) => {
  Game.find().then(games => {
    const todaysGames = games.filter(game => isToday(game.start_time))
    return res.json(todaysGames)
  })
})

// router.get('/:gameId', (req, res) => {
//   Game.findById(req.params.gameId, (err,
//     game) => {
//     if (!!game) {
//       return res.json(game)
//     } else {
//       return res.status(404).json({
//         "msg":
//           "Game not found"
//       })
//     }
//   })
// })
module.exports = router;